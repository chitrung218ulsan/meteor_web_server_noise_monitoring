(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/bootstrap.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.startup(function () {                                           // 1
	Data._ensureIndex({ "nodeNumber": 1 });                               // 3
	Data._ensureIndex({ "createdAt": 1 });                                // 4
	//Apartment.remove({});                                               //
	//Building.remove({});                                                //
	//Home.remove({});                                                    //
	//Node.remove({});                                                    //
	//Data.remove({});                                                    //
                                                                       //
	/*var apart1 = {                                                      //
 	name: "Lotte",                                                       //
 	type: "아바트",                                                         //
 	address: "Ulsan",                                                    //
 	numOfBuildings:10,                                                   //
 	numOfHomes:20,                                                       //
 	constructDate: new Date(),                                           //
 	manager: "Trung",                                                    //
 	createdBy: "Trung",                                                  //
 	remarks: "Lotte"                                                     //
 };                                                                    //
 	var building1 = {                                                    //
 	name: "Building 1",                                                  //
 	buildingNumber: 1,                                                   //
 	numOfFloors: 7,                                                      //
 	numHousePerFloor: 6,                                                 //
 	type: "계단식",                                                         //
 	manager: "Trung",                                                    //
 	representative: "Trung",                                             //
 	createdBy: "Trung",                                                  //
 	remarks: "Building 1"                                                //
 };                                                                    //
 	var building2 = {                                                    //
 	name: "Building 2",                                                  //
 	buildingNumber: 3,                                                   //
 	numOfFloors: 2,                                                      //
 	numHousePerFloor: 3,                                                 //
 	type: "계단식",                                                         //
 	manager: "Trung",                                                    //
 	representative:"Trung",                                              //
 	createdBy: "Hieu Ngo",                                               //
 	remarks: "Building 2"                                                //
 };                                                                    //
 	var node1 = {                                                        //
 	name: "Node 1",                                                      //
 	nodeNumber: 1,                                                       //
 	hardwareVersion: "Hard V1",                                          //
 	softwareVersion: 'Soft V1',                                          //
 	nodeSerial: "1111",                                                  //
 	remarks: "Node 1",                                                   //
 	createdBy: "Hieu"                                                    //
 };                                                                    //
 	var node2 = {                                                        //
 	name: "Node 2",                                                      //
 	nodeNumber: 2,                                                       //
 	hardwareVersion: "Hard V2",                                          //
 	softwareVersion: 'Soft V2',                                          //
 	nodeSerial: "2222",                                                  //
 	remarks: "Node 2",                                                   //
 	createdBy: "Hieu"                                                    //
 };                                                                    //
 	var node3 = {                                                        //
 	name: "Node 3",                                                      //
 	nodeNumber: 3,                                                       //
 	hardwareVersion: "Hard V2",                                          //
 	softwareVersion: 'Soft V2',                                          //
 	nodeSerial: "2222",                                                  //
 	remarks: "Node 3",                                                   //
 	createdBy: "Hieu"                                                    //
 };                                                                    //
 	var home1 = {                                                        //
 	floor: 1,                                                            //
 	homeNumber: 101,                                                     //
 	name: 'Hieu',                                                        //
 	telNumber: '7889302',                                                //
 	createdBy: "Hieu Ngo",                                               //
 	homeSize: 60,                                                        //
 	nodeId: 1,                                                           //
 	sound:0,                                                             //
 	vibration:0,                                                         //
 	nodeBattery:0,                                                       //
 	remarks: "home1"                                                     //
 };                                                                    //
 	var home2 = {                                                        //
 	floor: 2,                                                            //
 	homeNumber: 201,                                                     //
 	name: 'Hieu',                                                        //
 	telNumber: '9999999',                                                //
 	createdBy: "Hieu Ngo",                                               //
 	homeSize: 60,                                                        //
 	nodeId: 1,                                                           //
 	sound:0,                                                             //
 	vibration:0,                                                         //
 	nodeBattery:0,                                                       //
 	remarks: "home2"                                                     //
 };                                                                    //
 	var home3 = {                                                        //
 	floor: 1,                                                            //
 	homeNumber: 301,                                                     //
 	name: 'Hieu',                                                        //
 	telNumber: '7889302',                                                //
 	createdBy: "Hieu Ngo",                                               //
 	homeSize: 60,                                                        //
 	nodeId: 1,                                                           //
 	sound:0,                                                             //
 	vibration:0,                                                         //
 	nodeBattery:0,                                                       //
 	remarks: "home1"                                                     //
 };                                                                    //
 	var home4 = {                                                        //
 	floor: 2,                                                            //
 	homeNumber: 401,                                                     //
 	name: 'Hieu',                                                        //
 	telNumber: '9999999',                                                //
 	createdBy: "Hieu Ngo",                                               //
 	homeSize: 60,                                                        //
 	nodeId: 1,                                                           //
 	sound:0,                                                             //
 	vibration:0,                                                         //
 	nodeBattery:0,                                                       //
 	remarks: "home2"                                                     //
 };                                                                    //
 */                                                                    //
                                                                       //
	/*Apartment.insert(apart1, function(err,obj){                         //
 	if(err){                                                             //
 		console.log(err);                                                   //
 		return;                                                             //
 	}                                                                    //
 	building1.apartmentId = obj;                                         //
 	building2.apartmentId = obj;                                         //
 	                                                                     //
 		Building.insert(building1,function(err,bu1){                        //
 		if(err){                                                            //
 			console.log(err);                                                  //
 			return;                                                            //
 		}                                                                   //
 			home1.buildingId = bu1;                                            //
 			Node.insert(node1, function(err,realNode1){                        //
 			home1.nodeId = realNode1;                                          //
 			var data1 = {                                                      //
 				nodeNumber: node1.nodeNumber,                                     //
 				sound: 10,                                                        //
 				vibration: 15,                                                    //
 				battery: 2,                                                       //
 				createdBy: "Hieu"                                                 //
 			};                                                                 //
 			var data2 = {                                                      //
 				nodeNumber: node1.nodeNumber,                                     //
 				sound: 20,                                                        //
 				vibration: 10,                                                    //
 				battery: 4,                                                       //
 				createdBy: "Hieu"                                                 //
 			};                                                                 //
 			Data.insert(data1);                                                //
 			Data.insert(data2);                                                //
 			Home.insert(home1, function(err,hu1){                              //
 				console.log(err);                                                 //
 			});                                                                //
 		});                                                                 //
 			home2.buildingId = bu1;                                            //
 		Node.insert(node2,function(err,realNode2){                          //
 			home2.nodeId = realNode2;                                          //
 			var data1 = {                                                      //
 				nodeNumber: node2.nodeNumber,                                     //
 				sound: 20,                                                        //
 				vibration: 10,                                                    //
 				battery: 2,                                                       //
 				createdBy: "Hieu"                                                 //
 			};                                                                 //
 			var data2 = {                                                      //
 				nodeNumber: node2.nodeNumber,                                     //
 				sound: 500,                                                       //
 				vibration: 13,                                                    //
 				battery: 4,                                                       //
 				createdBy: "Hieu"                                                 //
 			};                                                                 //
 			Data.insert(data1);                                                //
 			Data.insert(data2);                                                //
 			Home.insert(home2,function(err,hu2){                               //
 				console.log(err);                                                 //
 			});                                                                //
 		})                                                                  //
 	});                                                                  //
 	Building.insert(building2, function(err,bu2){                        //
 		if(err){                                                            //
 			console.log(err);                                                  //
 			return;                                                            //
 		}                                                                   //
 		home3.buildingId = bu2;                                             //
 		Node.insert(node3,function(err,realNode2){                          //
 			home3.nodeId = realNode2;                                          //
 			var data1 = {                                                      //
 				nodeNumber: node3.nodeNumber,                                     //
 				sound: 100,                                                       //
 				vibration: 150,                                                   //
 				battery: 2,                                                       //
 				createdBy: "Hieu"                                                 //
 			};                                                                 //
 			var data2 = {                                                      //
 				nodeNumber: node3.nodeNumber,                                     //
 				sound: 50,                                                        //
 				vibration: 13,                                                    //
 				battery: 4,                                                       //
 				createdBy: "Hieu"                                                 //
 			};                                                                 //
 			Data.insert(data1);                                                //
 			Data.insert(data2);                                                //
 			Home.insert(home3,function(err,hu2){                               //
 				console.log(err);                                                 //
 			});                                                                //
 		})                                                                  //
 		});                                                                 //
 });*/                                                                 //
                                                                       //
	var wsURL = 'ws://192.168.0.28:9003/websockets/data_service';         // 231
	var Websocket = Meteor.npmRequire('recon-ws');                        // 232
	startWebsocket();                                                     // 233
                                                                       //
	/*                                                                    //
 Function Defitions                                                    //
 */                                                                    //
	Accounts.validateLoginAttempt(function (attempt) {                    // 238
		if (attempt.allowed) {                                               // 239
			console.log('login sucess');                                        // 241
			console.log(attempt.user);                                          // 242
			return true;                                                        // 243
		}                                                                    //
	});                                                                   //
	Accounts.config({                                                     // 246
		forbidClientAccountCreation: false                                   // 247
	});                                                                   //
	/*******************************************************************************/
                                                                       //
	function startWebsocket() {                                           // 251
		var Future = Npm.require('fibers');                                  // 252
		var ws = new Websocket(wsURL);                                       // 253
                                                                       //
		ws.on('open', function () {                                          // 255
			console.log('connection opened');                                   // 257
		});                                                                  //
		ws.on('close', function () {                                         // 259
			console.log('connection closed');                                   // 260
		});                                                                  //
		ws.on('error', function () {                                         // 262
			console.log('connection error');                                    // 263
		});                                                                  //
		ws.on('message', Meteor.bindEnvironment(function (msg) {             // 265
			console.log('Got message');                                         // 266
			readWsData(msg);                                                    // 267
		}));                                                                 //
	}                                                                     //
                                                                       //
	function readWsData(data) {                                           // 271
		try {                                                                // 273
                                                                       //
			var json = JSON.parse(data);                                        // 275
			console.log(json);                                                  // 276
			var nodeId = json.nodeId;                                           // 277
			//var houseNumber = 1;//House.findOne({nodeId:nodeId});             //
			var sound = json.sound;                                             // 279
			var vibration = json.vibration;                                     // 280
			var battery = json.battery;                                         // 281
			var minSound = json.minSound;                                       // 282
			var minVibration = json.minVibration;                               // 283
			var maxSound = json.maxSound;                                       // 284
			var maxVibration = json.maxVibration;                               // 285
                                                                       //
			var nodeEntry = Node.findOne({ nodeNumber: nodeId });               // 287
			var objNodeId = nodeEntry._id;                                      // 288
                                                                       //
			var inputData = {                                                   // 290
				nodeNumber: nodeId,                                                // 292
				sound: sound,                                                      // 293
				vibration: vibration,                                              // 294
				battery: battery,                                                  // 295
				minSound: minSound,                                                // 296
				minVibration: minVibration,                                        // 297
				maxSound: maxSound,                                                // 298
				maxVibration: maxVibration,                                        // 299
				createdBy: "Trung"                                                 // 300
			};                                                                  //
                                                                       //
			// Insert received data into Data Collection                        //
			if (!nodeEntry.isDeleted) {                                         // 305
				Data.insert(inputData);                                            // 307
			}                                                                   //
                                                                       //
			// Update value in House                                            //
                                                                       //
			Home.update({ 'nodeId': objNodeId, 'isDeleted': false }, { $set: {  // 313
					sound: sound,                                                     // 315
					vibration: vibration,                                             // 316
					nodeBattery: battery,                                             // 317
					minSound: minSound,                                               // 318
					minVibration: minVibration,                                       // 319
					maxSound: maxSound,                                               // 320
					maxVibration: maxVibration,                                       // 321
					lastDataUpdate: new Date()                                        // 322
				} }, { multi: false });                                            //
		} catch (e) {}                                                       //
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=bootstrap.js.map
