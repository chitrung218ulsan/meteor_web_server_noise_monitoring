(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publish.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish(SoundMonitor.Constants.APARTMENT_SOURCE, function () {  // 1
	return Apartment.find({ isDeleted: false });                          // 2
});                                                                    //
Meteor.publish(SoundMonitor.Constants.BUILDING_SOURCE, function () {   // 4
	return Building.find({ isDeleted: false });                           // 5
});                                                                    //
Meteor.publish(SoundMonitor.Constants.HOME_SOURCE, function () {       // 7
	return Home.find({ isDeleted: false });                               // 8
});                                                                    //
Meteor.publish(SoundMonitor.Constants.NODE_SOURCE, function () {       // 10
	return Node.find({ isDeleted: false });                               // 11
});                                                                    //
Meteor.publish(SoundMonitor.Constants.DATA_SOURCE, function (buildingId, startDate, endDate, soundThreshold, vibrationThreshold) {
	startDate.setHours(0, 0, 0, 0);                                       // 14
	endDate.setHours(23, 59, 59, 999);                                    // 15
	var nodes = [];                                                       // 16
	var bu = Building.findOne({ _id: buildingId });                       // 17
	if (bu) {                                                             // 18
		_.each(bu.homes().fetch(), function (ele, index, list) {             // 19
                                                                       //
			nodes.push(ele.node().nodeNumber);                                  // 21
		});                                                                  //
	}                                                                     //
                                                                       //
	return Data.find({ nodeNumber: { $in: nodes }, isDeleted: false, createdAt: { $gte: startDate, $lte: endDate }, $or: [{ sound: { $gte: soundThreshold } }, { vibration: { $gte: vibrationThreshold } }] }, { sort: { createdAt: 1 } });
});                                                                    //
                                                                       //
Meteor.publish("Sound-Vib-Data", function (buildingId, startDate, endDate, soundThreshold, vibrationThreshold) {
	startDate.setHours(0, 0, 0, 0);                                       // 30
	endDate.setHours(23, 59, 59, 999);                                    // 31
	var self = this;                                                      // 32
	var nodes = [];                                                       // 33
	var bu = Building.findOne({ _id: buildingId });                       // 34
	if (bu) {                                                             // 35
		_.each(bu.homes().fetch(), function (ele, index, list) {             // 36
                                                                       //
			nodes.push(ele.node().nodeNumber);                                  // 38
		});                                                                  //
	}                                                                     //
                                                                       //
	nodes.forEach(function (node) {                                       // 44
                                                                       //
		var datas = Data.find({ nodeNumber: node, isDeleted: false, createdAt: { $gte: startDate, $lte: endDate } }, { sort: { createdAt: 1 } });
		var maxSound = 0;                                                    // 47
		var maxVib = 0;                                                      // 48
		var numOfSoundOverThreshold = 0;                                     // 49
		var numOfVibOverThreshold = 0;                                       // 50
                                                                       //
		_.each(datas.fetch(), function (element, index, list) {              // 52
                                                                       //
			if (element.sound > maxSound) maxSound = element.sound;             // 55
                                                                       //
			if (element.vibration > maxVib) maxVib = element.vibration;         // 58
                                                                       //
			if (element.sound > soundThreshold) numOfSoundOverThreshold++;      // 61
                                                                       //
			if (element.vibration > vibrationThreshold) numOfVibOverThreshold++;
		});                                                                  //
		self.added('SoundData', node, {                                      // 69
			nodeNumber: node,                                                   // 70
			maxSound: maxSound,                                                 // 71
			numOfSoundOverThreshold: numOfSoundOverThreshold                    // 72
		});                                                                  //
	});                                                                   //
	return SoundData.find({});                                            // 75
	//return Data.find({nodeNumber : {$in :  nodes},isDeleted: false, createdAt: {$gte: startDate, $lte: endDate},$or:[{sound:{$gte:soundThreshold}},{vibration:{$gte:vibrationThreshold}}]},{sort:{createdAt:1}});
});                                                                    //
                                                                       //
Meteor.publish('SoundData', function (buildingId, startDate, endDate, soundThreshold) {
	startDate.setHours(0, 0, 0, 0);                                       // 81
	endDate.setHours(23, 59, 59, 999);                                    // 82
	var self = this;                                                      // 83
	var nodes = [];                                                       // 84
	var bu = Building.findOne({ _id: buildingId });                       // 85
	if (bu) {                                                             // 86
		_.each(bu.homes().fetch(), function (ele, index, list) {             // 87
                                                                       //
			nodes.push(ele.node().nodeNumber);                                  // 89
		});                                                                  //
	}                                                                     //
                                                                       //
	//console.log(soundThreshold);                                        //
	var sound_threshold = parseFloat(soundThreshold);                     // 95
	var pipeline = [{ "$match": {                                         // 96
			nodeNumber: { $in: nodes },                                         // 98
			isDeleted: false,                                                   // 99
			createdAt: { $gte: startDate, $lte: endDate },                      // 100
			sound: { $gte: sound_threshold }                                    // 101
		}                                                                    //
	}, { "$group": {                                                      //
			_id: "$nodeNumber",                                                 // 105
                                                                       //
			maxSound: { $max: "$sound" },                                       // 107
                                                                       //
			numOfSoundOverThreshold: { $sum: 1 }                                // 109
		}                                                                    //
	}];                                                                   //
                                                                       //
	var results = Data.aggregate(pipeline);                               // 115
	results.forEach(function (result) {                                   // 116
		//console.log(result);                                               //
		self.added('SoundData', result._id, {                                // 118
			nodeNumber: result._id,                                             // 119
			maxSound: result.maxSound,                                          // 120
			numOfSoundOverThreshold: result.numOfSoundOverThreshold             // 121
		});                                                                  //
	});                                                                   //
});                                                                    //
                                                                       //
Meteor.publish('VibData', function (buildingId, startDate, endDate, vibrationThreshold) {
	startDate.setHours(0, 0, 0, 0);                                       // 128
	endDate.setHours(23, 59, 59, 999);                                    // 129
	var self = this;                                                      // 130
	var nodes = [];                                                       // 131
	var bu = Building.findOne({ _id: buildingId });                       // 132
	if (bu) {                                                             // 133
		_.each(bu.homes().fetch(), function (ele, index, list) {             // 134
                                                                       //
			nodes.push(ele.node().nodeNumber);                                  // 136
		});                                                                  //
	}                                                                     //
                                                                       //
	var vib_threshold = parseFloat(vibrationThreshold);                   // 141
                                                                       //
	var cond = [{ nodeNumber: { $in: nodes } }, { isDeleted: false }, { createdAt: { $gte: startDate, $lte: endDate } }, { vibration: { $gte: vib_threshold } }];
	var pipeline = [{ $match: {                                           // 150
			$and: cond                                                          // 152
		}                                                                    //
	}, { "$group": {                                                      //
			_id: "$nodeNumber",                                                 // 156
                                                                       //
			maxVib: { $max: "$vibration" },                                     // 158
                                                                       //
			numOfVibOverThreshold: { $sum: 1 }                                  // 160
		}                                                                    //
	}];                                                                   //
                                                                       //
	var results = Data.aggregate(pipeline);                               // 168
	results.forEach(function (result) {                                   // 169
		console.log(result);                                                 // 170
		self.added('VibData', result._id, {                                  // 171
			nodeNumber: result._id,                                             // 172
			maxVib: result.maxVib,                                              // 173
			numOfVibOverThreshold: result.numOfVibOverThreshold                 // 174
		});                                                                  //
	});                                                                   //
});                                                                    //
                                                                       //
Meteor.publish('testData', function (nodeNumber, soundThreshold, vibThreshold, startDate, endDate) {
                                                                       //
	//console.log(homeArray);                                             //
	startDate.setHours(0, 0, 0, 0);                                       // 183
	endDate.setHours(23, 59, 59, 999);                                    // 184
	/*var nodes = [];                                                     //
 homeArray.forEach(function(element,index,array){                      //
 	var home = Home.findOne({_id: element});                             //
 	if(home){                                                            //
 		var node = home.node();                                             //
 		nodes.push(node.nodeNumber);                                        //
 	}                                                                    //
 });*/                                                                 //
	var threshold_sound = parseFloat(soundThreshold);                     // 193
	var threshold_vib = parseFloat(vibThreshold);                         // 194
	return Data.find({ nodeNumber: nodeNumber, isDeleted: false, $or: [{ sound: { $gte: threshold_sound } }, { vibration: { $gte: threshold_vib } }], createdAt: { $gte: startDate, $lte: endDate } }, { "nodeNumber": 1, "sound": 1, "vibration": 1, "createdAt": 1 }, { sort: { createdAt: 1 } });
	//return Data.find({nodeNumber : {$in :  nodes},isDeleted: false,$or:[{sound:{$gte:threshold_sound}},{vibration:{$gte:threshold_vib}}],createdAt:{$gte:startDate,$lte:endDate}},{"nodeNumber":1,"sound":1,"vibration":1,"createdAt":1},{sort:{createdAt:1}});
});                                                                    //
                                                                       //
Meteor.publish('sound_vib_graph', function (nodeNumber, soundThreshold, vibThreshold, startDate, endDate) {
                                                                       //
	var self = this;                                                      // 201
	startDate.setHours(0, 0, 0, 0);                                       // 202
	endDate.setHours(23, 59, 59, 999);                                    // 203
	var threshold_sound = parseFloat(soundThreshold);                     // 204
	var threshold_vib = parseFloat(vibThreshold);                         // 205
	var cond = [{ nodeNumber: nodeNumber }, { isDeleted: false }, { createdAt: { $gte: startDate, $lte: endDate } }, { $and: [{ sound: { $gte: threshold_sound } }, { vibration: { $gte: threshold_vib } }] }];
	var pipeline = [{ $match: {                                           // 213
			$and: cond                                                          // 215
		}                                                                    //
	}, { "$group": {                                                      //
			_id: { month: { $month: "$createdAt" }, day: { $dayOfMonth: "$createdAt" }, year: { $year: "$createdAt" },
				hour: { $hour: "$createdAt" }, minutes: { $minute: "$createdAt" } },
			maxSound: { $max: "$sound" },                                       // 221
			maxVib: { $max: "$vibration" },                                     // 222
			nodeNumber: { $max: "$nodeNumber" }                                 // 223
		}                                                                    //
	}, {                                                                  //
		$sort: { _id: 1 }                                                    // 227
	}, { $project: {                                                      //
			_id: '$nodeNumber',                                                 // 229
			nodeNumber: '$nodeNumber',                                          // 230
			date: "$_id",                                                       // 231
			sound: "$maxSound",                                                 // 232
			vib: "$maxVib"                                                      // 233
                                                                       //
		}                                                                    //
	}];                                                                   //
                                                                       //
	var lastTrackMinute = new Date();                                     // 240
	var start = true;                                                     // 241
	var results = Data.aggregate(pipeline);                               // 242
                                                                       //
	results.forEach(function (doc) {                                      // 244
                                                                       //
		var createdDate = new Date(doc.date.year, doc.date.month - 1, doc.date.day, doc.date.hour, doc.date.minutes, 0, 0);
		//console.log(createdDate);                                          //
                                                                       //
		var d = Date.UTC(doc.date.year, doc.date.month, doc.date.day, doc.date.hour, doc.date.minutes, 0, 0);
		//print(d);                                                          //
		if (start == true) {                                                 // 252
			lastTrackMinute = Date.UTC(doc.date.year, doc.date.month, doc.date.day, doc.date.hour, doc.date.minutes, 0, 0);
			start = false;                                                      // 254
		}                                                                    //
		var timeCompare = d - lastTrackMinute;                               // 257
		//print(a);                                                          //
		if (timeCompare >= 120000) {                                         // 259
                                                                       //
			lastTrackMinute = Date.UTC(doc.date.year, doc.date.month, doc.date.day, doc.date.hour, doc.date.minutes, 0, 0);
			console.log(doc);                                                   // 263
                                                                       //
			self.added('SoundVibDataGraph', doc._id, {                          // 265
				nodeNumber: doc.nodeNumber,                                        // 266
				sound: doc.sound,                                                  // 267
				vib: doc.vib,                                                      // 268
				createdAt: createdDate                                             // 269
			});                                                                 //
		}                                                                    //
		/*(self.added ('SoundVibDataGraph',doc._id,{                         //
  	nodeNumber:doc._id,                                                 //
  	maxSound:doc.sound,                                                 //
  	maxVib:doc.vib,                                                     //
  	dateTime:createdDate                                                //
  });*/                                                                //
	});                                                                   //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publish.js.map
