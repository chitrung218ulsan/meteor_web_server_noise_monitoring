(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/methods.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
	'soundData': function (nodeNumber, soundThreshold, vibThreshold, startDate, endDate) {
                                                                       //
		startDate.setHours(0, 0, 0, 0);                                      // 4
		endDate.setHours(23, 59, 59, 999);                                   // 5
                                                                       //
		var testData = [];                                                   // 9
		//var home = Home.findOne({nodeId:nodeId});                          //
		//var node = home.node();                                            //
		var sound_threshold = parseFloat(soundThreshold);                    // 12
		var vib_threshold = parseFloat(vibThreshold);                        // 13
                                                                       //
		var datas = Data.find({ nodeNumber: nodeNumber, isDeleted: false, $or: [{ sound: { $gte: sound_threshold } }, { vibration: { $gte: vib_threshold } }], createdAt: { $gte: startDate, $lte: endDate }
		}, { "nodeNumber": 1, "sound": 1, "vibration": 1, "createdAt": 1 }, { sort: { createdAt: 1 } });
                                                                       //
		_.each(datas.fetch(), function (element, index, list) {              // 18
                                                                       //
			var tempData = { nodeNumber: element.nodeNumber, createdAt: element.createdAt, sound: element.sound, vibration: element.vibration };
                                                                       //
			testData.push(tempData);                                            // 22
		});                                                                  //
		return testData;                                                     // 24
	},                                                                    //
	'soundVibData': function (nodeNumber, soundThreshold, vibThreshold, startDate, endDate) {
                                                                       //
		startDate.setHours(0, 0, 0, 0);                                      // 30
		endDate.setHours(23, 59, 59, 999);                                   // 31
		//console.log(endDate);                                              //
		var UTC_starDate = Date.UTC(startDate.getFullYear(), startDate.getMonth() - 1, startDate.getDate(), startDate.getHours(), startDate.getMinutes(), 0, 0);
		var UTC_endDate = Date.UTC(endDate.getFullYear(), endDate.getMonth() - 1, endDate.getDate(), endDate.getHours(), endDate.getMinutes(), 0, 0);
		var timeThreshold = 0;                                               // 35
		//console.log(UTC_starDate);                                         //
		//console.log(UTC_endDate);                                          //
		if (UTC_endDate - UTC_starDate <= 86400000) {                        // 38
			timeThreshold = 60000;                                              // 40
		} else if (86400000 < UTC_endDate - UTC_starDate <= 604800000) {     //
			timeThreshold = 60000;                                              // 44
		} else {                                                             //
			timeThreshold = 60000;                                              // 47
		}                                                                    //
		var threshold_sound = parseFloat(soundThreshold);                    // 49
		var threshold_vib = parseFloat(vibThreshold);                        // 50
		var cond = [{ nodeNumber: nodeNumber }, { isDeleted: false }, { createdAt: { $gte: startDate, $lte: endDate } }, { $or: [{ sound: { $gte: threshold_sound } }, { vibration: { $gte: threshold_vib } }] }];
		var pipeline = [{ $match: {                                          // 58
				//$and:cond                                                        //
				nodeNumber: nodeNumber,                                            // 61
				isDeleted: false,                                                  // 62
				createdAt: { $gte: startDate, $lte: endDate },                     // 63
				$or: [{ sound: { $gte: threshold_sound } }, { vibration: { $gte: threshold_vib } }]
			}                                                                   //
		}, { "$group": {                                                     //
				_id: { month: { $month: "$createdAt" }, day: { $dayOfMonth: "$createdAt" }, year: { $year: "$createdAt" },
					hour: { $hour: "$createdAt" }, minutes: { $minute: "$createdAt" } },
				maxSound: { $max: "$sound" },                                      // 70
				maxVib: { $max: "$vibration" },                                    // 71
				nodeNumber: { $max: "$nodeNumber" }                                // 72
			}                                                                   //
		}, {                                                                 //
			$sort: { _id: 1 }                                                   // 76
		}, { $project: {                                                     //
				_id: '$nodeNumber',                                                // 78
				nodeNumber: '$nodeNumber',                                         // 79
				date: "$_id",                                                      // 80
				sound: "$maxSound",                                                // 81
				vib: "$maxVib"                                                     // 82
                                                                       //
			}                                                                   //
		}];                                                                  //
                                                                       //
		var lastTrackMinute = new Date();                                    // 89
		var start = true;                                                    // 90
		var testData = [];                                                   // 91
		var results = Data.aggregate(pipeline);                              // 92
		//console.log(results.length);                                       //
		results.forEach(function (doc) {                                     // 94
                                                                       //
			var createdDate = new Date(Date.UTC(doc.date.year, doc.date.month - 1, doc.date.day, doc.date.hour, doc.date.minutes, 0, 0));
			//console.log(createdDate);                                         //
                                                                       //
			var d = Date.UTC(doc.date.year, doc.date.month - 1, doc.date.day, doc.date.hour, doc.date.minutes, 0, 0);
			//print(d);                                                         //
			if (start == true) {                                                // 102
				lastTrackMinute = d;                                               // 103
				start = false;                                                     // 104
			}                                                                   //
			var timeCompare = d - lastTrackMinute;                              // 107
			//print(a);                                                         //
			if (timeCompare >= timeThreshold) {                                 // 109
                                                                       //
				lastTrackMinute = d;                                               // 112
				//console.log(doc);                                                //
                                                                       //
				var tempData = { nodeNumber: doc.nodeNumber, sound: doc.sound, vib: doc.vib, createdAt: createdDate };
                                                                       //
				testData.push(tempData);                                           // 117
			}                                                                   //
			/*(self.added ('SoundVibDataGraph',doc._id,{                        //
   	nodeNumber:doc._id,                                                //
   	maxSound:doc.sound,                                                //
   	maxVib:doc.vib,                                                    //
   	dateTime:createdDate                                               //
   });*/                                                               //
		});                                                                  //
		return testData;                                                     // 127
	}                                                                     //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
